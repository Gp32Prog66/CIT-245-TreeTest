#include<string>
#include<iostream>
using namespace std;



class TreeNode{
  public:

  TreeNode(TreeNode* p)
    :parent{p}
  {

  }

  TreeNode(TreeNode* p, string k, int pwr)
    :parent{p},keyName{k},valMW{pwr}
  {
    
  }

    TreeNode* parent;
    TreeNode* childL;
    TreeNode* childR;
    string keyName;
    int valMW;
};

TreeNode* root;

int main(){
  TreeNode* node = new TreeNode(nullptr);
  root = node;

  string sm = "abk";
  string eq = "abk";
  string lg = "zxv";
  cout << eq.compare(sm);

}